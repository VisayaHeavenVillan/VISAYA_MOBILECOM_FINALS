// components/DetailsScreen.js

//Dito sa .js na to dinidisplay nya yung information about sa pinili mong computer parts sa homescreen (CPU, GPU, RAM, etc.)

//ipapakita din sa ang icon or image nung sinelect mo, name nung part, short description ant yung top 3 brands nung nagawa nung parts ng ccomputer na iyon

import React from 'react';
import { View, Text, Image, StyleSheet, ScrollView } from 'react-native';

const DetailsScreen = ({ route }) => {
  const { part } = route.params; // Receive the part object passed from HomeScreen

  return (
    <ScrollView style={styles.container}>
      <Image source={part.image} style={styles.image} />
      <Text style={styles.title}>{part.name}</Text>
      <Text style={styles.description}>{part.description}</Text>
      <Text style={styles.brandsTitle}>Top Brands:</Text>
      {part.topBrands.map((brand, index) => (
        <Text key={index} style={styles.brand}>{brand}</Text> // Loop through and display each brand
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: 'white',
  },
  image: {
    width: '100%',
    height: 200,
    resizeMode: 'contain',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginVertical: 10,
  },
  description: {
    fontSize: 16,
    marginVertical: 10,
    lineHeight: 24,
  },
  brandsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginVertical: 10,
  },
  brand: {
    fontSize: 16,
    marginVertical: 5,
  },
});

export default DetailsScreen;
