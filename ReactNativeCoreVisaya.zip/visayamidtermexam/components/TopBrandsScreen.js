//ToBransScreen.js

//Dto ang naman nililist nya yung top recommended brands, gumamit din tayo ng <Flatlist> para idisplay ang ,ga brand names na galing din sa compute parts or array sa  data.js

//ADDITIONAL NOTE: last week ko pa to ginawa sir, inadd ko lang ngayon yung listview kaya nadagdagan nung button na "recomended top brands"


import React from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';

const topBrands = [
  { id: '1', name: 'ASUS' },
  { id: '2', name: 'MSI' },
  { id: '3', name: 'Intel' },
  { id: '4', name: 'AMD' },
  { id: '5', name: 'NVIDIA' },
  { id: '6', name: 'Gigabyte' },
  { id: '7', name: 'Corsair' },
];

export default function TopBrandsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Recommended Top Brands</Text>

      <FlatList
        data={topBrands}
        keyExtractor={(item) => item.id} 
        renderItem={({ item }) => (
          <View style={styles.brandCard}>
            <Text style={styles.brandName}>{item.name}</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#fff',
    flex: 1,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center',
  },
  brandCard: {
    backgroundColor: '#3498db',
    padding: 15,
    marginVertical: 8,
    borderRadius: 10,
  },
  brandName: {
    color: '#fff',
    fontSize: 18,
  },
});




