// components/data.js

//Ang .js na to ay dto naka store ang mga data para sa mga computer parts ko tulad ng Name, Description, Topbrands, at image nung parts nung computer,ginamitan ko ng array na ang panaglan ay computerParts 

export const computerParts = [
  {
    name: 'CPU',
    description: 'The CPU is the "brain" of the computer, handling all instructions and tasks necessary for the system\'s operation.',
    topBrands: ['Intel', 'AMD', 'Apple (M1/M2 chips)'],
    image: require('../assets/cpu.png'),
  },
  {
    name: 'RAM',
    description: 'RAM is the computer’s short-term memory, allowing for quick data access and smooth multitasking.',
    topBrands: ['Corsair', 'G.SKILL', 'Kingston'],
    image: require('../assets/ram.png'),
  },
  {
    name: 'GPU',
    description: 'The GPU is responsible for rendering images, video, and animations, especially for gaming or graphic-intensive applications.',
    topBrands: ['NVIDIA', 'AMD', 'EVGA'],
    image: require('../assets/gpu.png'),
  },
  {
    name: 'Motherboard',
    description: 'The motherboard is the main circuit board that houses essential components like the CPU, RAM, and connectors for other peripherals.',
    topBrands: ['ASUS', 'MSI', 'Gigabyte'],
    image: require('../assets/motherboard.png'),
  },
  {
    name: 'Hard Drive (HDD/SSD)',
    description: 'The hard drive stores all data, including the operating system, applications, and files. SSDs are faster than traditional HDDs.',
    topBrands: ['Samsung', 'Western Digital', 'Seagate'],
    image: require('../assets/harddrive.png'),
  },
  {
    name: 'PSU (Power Supply Unit)',
    description: 'The PSU converts electricity from a wall outlet into the power needed to run internal computer components.',
    topBrands: ['Corsair', 'Seasonic', 'EVGA'],
    image: require('../assets/psu.png'),
  },
];
