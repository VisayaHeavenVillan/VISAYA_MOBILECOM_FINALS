//buildscreen.js

//And .js naman na ito ang purpose nya is yung help users to build a computer, meron tong 16 steps na may checkbox at progress percentage each time na nag ccheck yung user sa steps.

import React, { useState } from 'react';
import { View, Text, StyleSheet, Button, ScrollView, ProgressBar } from 'react-native';
import { Checkbox } from 'react-native-paper';  // Import Checkbox from react-native-paper

export default function BuildGuideScreen({ navigation }) {
  const [stepsChecked, setStepsChecked] = useState(new Array(16).fill(false));

  const handleCheckboxChange = (index) => {
    const newStepsChecked = [...stepsChecked];
    newStepsChecked[index] = !newStepsChecked[index];
    setStepsChecked(newStepsChecked);
  };

  const calculateProgress = () => {
    const totalChecked = stepsChecked.filter((checked) => checked).length;
    return Math.round((totalChecked / stepsChecked.length) * 100); // Round to the nearest integer
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>How to Build a Computer</Text>
      <Text style={styles.description}>Follow these steps to assemble your computer. Check each box as you complete the step!</Text>

      {/* Step 1 */}
      <View style={styles.stepContainer}>
        <Checkbox 
          status={stepsChecked[0] ? 'checked' : 'unchecked'} 
          onPress={() => handleCheckboxChange(0)} 
        />
        <Text style={styles.step}>
          1. Gather Your Components: CPU, Motherboard, RAM, Storage, GPU, PSU, Case, Cooling, OS, Optical Drive.
        </Text>
      </View>

      {/* Step 2 */}
      <View style={styles.stepContainer}>
        <Checkbox 
          status={stepsChecked[1] ? 'checked' : 'unchecked'} 
          onPress={() => handleCheckboxChange(1)} 
        />
        <Text style={styles.step}>
          2. Prepare Your Workspace: Clean, flat surface, anti-static wrist strap.
        </Text>
      </View>

      {/* Step 3 */}
      <View style={styles.stepContainer}>
        <Checkbox 
          status={stepsChecked[2] ? 'checked' : 'unchecked'} 
          onPress={() => handleCheckboxChange(2)} 
        />
        <Text style={styles.step}>
          3. Install the CPU: Open socket, align CPU, and place it gently.
        </Text>
      </View>

      {/* Step 4 */}
      <View style={styles.stepContainer}>
        <Checkbox 
          status={stepsChecked[3] ? 'checked' : 'unchecked'} 
          onPress={() => handleCheckboxChange(3)} 
        />
        <Text style={styles.step}>
          4. Install the CPU Cooler: Apply thermal paste, install air/liquid cooler.
        </Text>
      </View>

      {/* Step 5 */}
      <View style={styles.stepContainer}>
        <Checkbox 
          status={stepsChecked[4] ? 'checked' : 'unchecked'} 
          onPress={() => handleCheckboxChange(4)} 
        />
        <Text style={styles.step}>
          5. Install RAM: Open slots, align notches, press down until it clicks.
        </Text>
      </View>

      {/* Step 6 */}
      <View style={styles.stepContainer}>
        <Checkbox 
          status={stepsChecked[5] ? 'checked' : 'unchecked'} 
          onPress={() => handleCheckboxChange(5)} 
        />
        <Text style={styles.step}>
          6. Install Storage (SSD/HDD): Insert M.2 or SATA SSD/HDD into case and connect.
        </Text>
      </View>

      {/* Step 7 */}
      <View style={styles.stepContainer}>
        <Checkbox 
          status={stepsChecked[6] ? 'checked' : 'unchecked'} 
          onPress={() => handleCheckboxChange(6)} 
        />
        <Text style={styles.step}>
          7. Install the Motherboard: Align with standoffs, secure with screws.
        </Text>
      </View>

      {/* Step 8 */}
      <View style={styles.stepContainer}>
        <Checkbox 
          status={stepsChecked[7] ? 'checked' : 'unchecked'} 
          onPress={() => handleCheckboxChange(7)} 
        />
        <Text style={styles.step}>
          8. Install the Power Supply: Secure PSU, connect power cables to motherboard and GPU.
        </Text>
      </View>

      {/* Step 9 */}
      <View style={styles.stepContainer}>
        <Checkbox 
          status={stepsChecked[8] ? 'checked' : 'unchecked'} 
          onPress={() => handleCheckboxChange(8)} 
        />
        <Text style={styles.step}>
          9. Install the GPU: Insert into PCIe slot, secure with screws, connect PSU cables.
        </Text>
      </View>

      {/* Step 10 */}
      <View style={styles.stepContainer}>
        <Checkbox 
          status={stepsChecked[9] ? 'checked' : 'unchecked'} 
          onPress={() => handleCheckboxChange(9)} 
        />
        <Text style={styles.step}>
          10. Install Additional Case Fans: Secure fans, connect to motherboard or PSU.
        </Text>
      </View>

      {/* Step 11 */}
      <View style={styles.stepContainer}>
        <Checkbox 
          status={stepsChecked[10] ? 'checked' : 'unchecked'} 
          onPress={() => handleCheckboxChange(10)} 
        />
        <Text style={styles.step}>
          11. Connect All Cables: PSU to motherboard, CPU, storage, case connectors.
        </Text>
      </View>

      {/* Step 12 */}
      <View style={styles.stepContainer}>
        <Checkbox 
          status={stepsChecked[11] ? 'checked' : 'unchecked'} 
          onPress={() => handleCheckboxChange(11)} 
        />
        <Text style={styles.step}>
          12. Power On and Test: Ensure everything is connected, check BIOS/UEFI.
        </Text>
      </View>

      {/* Step 13 */}
      <View style={styles.stepContainer}>
        <Checkbox 
          status={stepsChecked[12] ? 'checked' : 'unchecked'} 
          onPress={() => handleCheckboxChange(12)} 
        />
        <Text style={styles.step}>
          13. Install the Operating System: Boot from USB and install the OS.
        </Text>
      </View>

      {/* Step 14 */}
      <View style={styles.stepContainer}>
        <Checkbox 
          status={stepsChecked[13] ? 'checked' : 'unchecked'} 
          onPress={() => handleCheckboxChange(13)} 
        />
        <Text style={styles.step}>
          14. Install Drivers and Software: Download and install necessary drivers.
        </Text>
      </View>

      {/* Step 15 */}
      <View style={styles.stepContainer}>
        <Checkbox 
          status={stepsChecked[14] ? 'checked' : 'unchecked'} 
          onPress={() => handleCheckboxChange(14)} 
        />
        <Text style={styles.step}>
          15. Final Check and Cable Management: Tidy up cables for better airflow.
        </Text>
      </View>

      {/* Step 16 */}
      <View style={styles.stepContainer}>
        <Checkbox 
          status={stepsChecked[15] ? 'checked' : 'unchecked'} 
          onPress={() => handleCheckboxChange(15)} 
        />
        <Text style={styles.step}>
          16. Enjoy Your New PC: Start installing software and games, and enjoy!
        </Text>
      </View>

      {/* Progress Bar */}
      <Text style={styles.progressText}>Progress: {calculateProgress()}%</Text>
      <ProgressBar 
        styleAttr="Horizontal"
        indeterminate={false}
        progress={calculateProgress() / 100}
        color="#3498db"
      />

      {/* Back Button */}
      <Button
        title="Go Back"
        onPress={() => navigation.goBack()}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1, // Ensures the content can grow and scroll if it's larger than the screen.
    backgroundColor: '#f0f0f0',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  description: {
    fontSize: 18,
    marginBottom: 20,
    textAlign: 'center',
  },
  stepContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  step: {
    fontSize: 16,
    marginLeft: 10,
    flex: 1,
  },
  progressText: {
    fontSize: 16,
    marginVertical: 20,
  },
});
