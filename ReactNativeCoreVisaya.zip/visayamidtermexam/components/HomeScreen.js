// components/HomeScreen.js

//navigation hub ng application ko

//Eto .js na to ay ginagamit sya ng application ko bilang homescreen, dto dinidisplay nya yung mga buttons ko na CPU, GPU, RAM, MOTHERBOARD, HARD DRIVE, PSU, "Build a Computer Guide", at "Top Recommended Brands"

//Ang computer parts ko is connected sa data.js

// 1. "Build a Computer Guide" na mag oopen ng BuildGuideScreen.js
// 2. "Top Recommended Brands" na mag oopen ng TopBrandsScreen.js




import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Image } from 'react-native';
import { computerParts } from './data';

export default function HomeScreen({ navigation }) {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Computer Components</Text>
      <View style={styles.grid}>
        {computerParts.map((part, index) => (
          <TouchableOpacity
            key={index}
            style={styles.button}
            onPress={() => navigation.navigate('Details', { part })}
          >
            <Image source={part.image} style={styles.image} />
            <Text style={styles.buttonText}>{part.name}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Button for Build a Computer Guide */}
      <TouchableOpacity
        style={styles.guideButton}
        onPress={() => navigation.navigate('BuildGuide')}
      >
        <Text style={styles.guideButtonText}>Build a Computer Guide</Text>
      </TouchableOpacity>

      {/* 🔥 New Button for Top Brands */}
      <TouchableOpacity
        style={[styles.guideButton, { backgroundColor: '#8e44ad' }]}
        onPress={() => navigation.navigate('TopBrands')}
      >
        <Text style={styles.guideButtonText}>Recommended Top Brands</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  button: {
    width: 140,
    height: 160,
    backgroundColor: '#3498db',
    margin: 10,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 20,
    padding: 10,
  },
  image: {
    width: 60,
    height: 60,
    marginBottom: 10,
    resizeMode: 'contain',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  guideButton: {
    backgroundColor: '#27ae60',
    marginTop: 20,
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 20,
  },
  guideButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
