// App.js

//  Ang .js na to ay dito iniimport lahat ng screens para matulungan ang application ko mag navigate gamit ang mga button (HomeScreen.js, DetailsScreen.js, BuildGuideScreen.js, at TopBrandsScreen.js)

import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeScreen from './components/HomeScreen';
import DetailsScreen from './components/DetailsScreen';
import BuildGuideScreen from './components/BuildGuideScreen';
import TopBrandsScreen from './components/TopBrandsScreen'; 

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Details" component={DetailsScreen} />
        <Stack.Screen name="BuildGuide" component={BuildGuideScreen} />
        <Stack.Screen name="TopBrands" component={TopBrandsScreen} /> 
      </Stack.Navigator>
    </NavigationContainer>
  );
}
