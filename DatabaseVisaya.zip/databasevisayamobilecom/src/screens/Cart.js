import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  Image,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';

const CART_KEY = 'cart';

const filipinoFoods = [
  { 
    id: 1,
    name: 'Lechon Kawali',
    price: 350.0,
    description: 'Malutong na balat at juicy na karne!', 
    image_url: 'https://panlasangpinoy.com/wp-content/uploads/2019/03/Lechon-Kawali-Recipe.jpg'
  },
  { 
    id: 2,
    name: 'Pork Sisig',
    price: 180.0,
    description: 'Mainit-init at maanghang na sisig!', 
    image_url: 'https://panlasangpinoy.com/wp-content/uploads/2019/12/sizzling-crispy-sisig-recipe-.jpg'
  },
  { 
    id: 5,
    name: 'Kare-Kare',
    price: 220.0,
    description: 'Masarap na ulam na may peanut sauce!', 
    image_url: 'https://panlasangpinoy.com/wp-content/uploads/2019/12/kare-kare-beef-tripe.jpg'
  },
  { 
    id: 6,
    name: 'Adobong Manok',
    price: 160.0,
    description: 'Classic Filipino adobo!', 
    image_url: 'https://panlasangpinoy.com/wp-content/uploads/2024/04/Filipino-Chicken-Adobo-Recipe-1024x672.jpg'
  },
  { 
    id: 7,
    name: 'Halo-Halo',
    price: 90.0,
    description: 'Matamis, malamig, puno ng sangkap!', 
    image_url: 'https://panlasangpinoy.com/wp-content/uploads/2011/05/512px-Halo_halo1.jpg'
  },
  { 
    id: 8,
    name: 'Leche Flan',
    price: 100.0,
    description: 'Matamis, makrema, creamy!', 
    image_url: 'https://panlasangpinoy.com/wp-content/uploads/2009/07/Leche-Flan_-jpg.webp'
  },
  { 
    id: 9,
    name: 'Buko Pandan',
    price: 80.0,
    description: 'Buko salad na may pandan jelly!', 
    image_url: 'https://panlasangpinoy.com/wp-content/uploads/2019/09/Buko-Pandan-Thumb-1024x683.jpg'
  },
  { 
    id: 10,
    name: 'Turon',
    price: 50.0,
    description: 'Saging na binalot!', 
    image_url: 'https://panlasangpinoy.com/wp-content/uploads/2009/06/Turon.jpg'
  },
  { 
    id: 11,
    name: 'Banana Cue',
    price: 35.0,
    description: 'Saging na ginawang matamis!', 
    image_url: 'https://panlasangpinoy.com/wp-content/uploads/2011/10/Bananacue.jpg'
  },
  { 
    id: 12,
    name: 'Kamote Cue',
    price: 30.0,
    description: 'Kamote na ginawang minatamis!', 
    image_url: 'https://panlasangpinoy.com/wp-content/uploads/2009/08/Kamote-Cue.jpg'
  },
  { 
    id: 13,
    name: 'Fish Balls',
    price: 20.0,
    description: 'Masarap na meryenda!', 
    image_url: 'https://panlasangpinoy.com/wp-content/uploads/2011/10/Fish-Balls.jpg'
  },
  { 
    id: 14,
    name: 'Kwek-Kwek',
    price: 25.0,
    description: 'Itlog na binalot!', 
    image_url: 'https://panlasangpinoy.com/wp-content/uploads/2009/09/kwekkwek-1024x76811.jpg'
  },
]

function formatToPhilippinePeso(amount) {
  return `₱${amount.toLocaleString('en-PH', { minimumFractionDigits: 2 })}`;
}

export default function Cart({ navigation }) {
  const [cartItems, setCartItems] = useState([]);

  useEffect(() => {
    loadCart();
  }, []);

  const loadCart = async () => {
    try {
      const json = await AsyncStorage.getItem(CART_KEY);
      if (json) setCartItems(JSON.parse(json)); 
    } catch (error) {
      console.error(error);
    }
  };

  const saveCart = async (items) => {
    try {
      await AsyncStorage.setItem(CART_KEY, JSON.stringify(items)); 
    } catch (error) {
      console.error(error);
    }
  };

  const updateQuantity = (itemId, qty) => {
    let updatedCart = [...cartItems].filter((item) => item.id !== itemId);
    if (qty > 0) {
      updatedCart.push({ id: itemId, quantity: qty });
    }
    setCartItems(updatedCart);
    saveCart(updatedCart);
  };

  const removeItem = (itemId) => {
    let updatedCart = [...cartItems].filter((item) => item.id !== itemId);
    setCartItems(updatedCart);
    saveCart(updatedCart);
    Alert.alert('Natanggal!', 'Natanggal ang item.');
  };

  const calculateTotal = () => {
    return cartItems.reduce((sum, item) => {
      const food = filipinoFoods.find((f) => f.id === item.id);
      return sum + (food ? food.price * item.quantity : 0);
    }, 0);
  };

  const renderCart = ({ item }) => {
    const food = filipinoFoods.find((f) => f.id === item.id);
    if (!food) return null;

    return (
      <View style={styles.card}>
        <Image source={{ uri: food.image_url }} style={styles.image} />
        <View style={styles.cardContent}>
          <Text style={styles.cardName}>{food.name}</Text>
          <Text style={styles.cardDesc}>{food.description}</Text>
          <Text style={styles.cardPrice}>{formatToPhilippinePeso(food.price)}</Text>
          <View style={styles.qtyControl}>
            <TouchableOpacity
              onPress={() =>
                updateQuantity(item.id, item.quantity - 1)
              }
            >
              <Ionicons name="remove-circle" size={24} color="#ff5252" />
            </TouchableOpacity>
            <Text style={styles.qtyText}>
              {item.quantity}
            </Text>
            <TouchableOpacity
              onPress={() =>
                updateQuantity(item.id, item.quantity + 1)
              }
            >
              <Ionicons name="add-circle" size={24} color="#4CAF50" />
            </TouchableOpacity>
          </View>
        </View>
        <TouchableOpacity
          style={styles.removeBtn}
          onPress={() => removeItem(item.id)}
        >
          <Ionicons name="trash" size={30} color="#ff5252" />
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>
        Cart
      </Text>

      {cartItems.length === 0 ? (
        <View style={styles.empty}>
          <Ionicons name="fast-food-outline" size={60} color="#fff" />
          <Text style={styles.emptyCartText}>
            Wala pa ang order mo
          </Text>
        </View>
      ) : (
        <>
          <FlatList
            data={cartItems}
            renderItem={renderCart}
            keyExtractor={(item) => item.id.toString()}
            contentContainerStyle={styles.cardList}
          />
          <View style={styles.footer}>
            <Text style={styles.total}>
              Total Price: {formatToPhilippinePeso(calculateTotal())}
            </Text>
            <TouchableOpacity style={styles.checkoutBtn}>
              <Text style={styles.checkoutBtnText}>
                PAY
              </Text>
            </TouchableOpacity>
          </View>
        </>
      )}

    </View>
  );
}

const styles = StyleSheet.create({  
   container: {
    flex: 1,
    backgroundColor: '#35ac2b',
    padding: 20,
  },
  title: {
    color: 'black',
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 30,
    textTransform: 'uppercase',
    textAlign: 'center',
  },
  cardList: { paddingBottom: 100 },
  card: {
    backgroundColor: '#fff2cc',
    borderRadius: 20,
    padding: 15,
    marginBottom: 15,
    elevation: 4,
    borderWidth: 1,
    borderColor: '#ffcc5b',
    flexDirection: 'row',
    alignItems: 'center',
    },
  image: { width: 80, height: 80, borderRadius: 10, marginRight: 15 },
  cardContent: { flex: 1 },
  cardName: { fontWeight: 'bold', fontSize: 18, color: '#ff7e5f' },
  cardDesc: { color: '#ff9f5b', marginBottom: 5 },
  cardPrice: { color: '#ff7e5f', fontWeight: 'bold', marginBottom: 10 },
  qtyControl: { flexDirection: 'row', alignItems: 'center' },
  qtyText: { marginHorizontal: 10, fontWeight: 'bold', fontSize: 16 },
  removeBtn: { padding: 10 },
  empty: { alignItems: 'center', marginTop: 50 },
  emptyCartText: { color: '#fff', fontSize: 18, marginBottom: 20 },
  footer: {
    padding: 15,
    backgroundColor: '#ffcc5b',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: '#fff',
  },
  total: { fontSize: 18, fontWeight: 'bold', marginBottom: 15 },
  checkoutBtn: {
    backgroundColor: '#ff7e5f',
    padding: 15,
    borderRadius: 30,
    alignItems: 'center',
    width: '80%',
  },
  checkoutBtnText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
});
