import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  Image,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';

const CART_KEY = 'cart';

const desserts = [
  {
    id: 7,
    name: 'Halo-Halo',
    price: 90.0,
    description: 'Matamis, malamig, puno ng sangkap!', 
    image_url: 'https://panlasangpinoy.com/wp-content/uploads/2011/05/512px-Halo_halo1.jpg',
  },
  {
    id: 8,
    name: 'Leche Flan',
    price: 100.0,
    description: 'Matamis, makrema, creamy!', 
    image_url: 'https://panlasangpinoy.com/wp-content/uploads/2009/07/Leche-Flan_-jpg.webp',
  },
  {
    id: 9,
    name: 'Buko Pandan',
    price: 80.0,
    description: 'Buko salad na may pandan jelly!', 
    image_url: 'https://panlasangpinoy.com/wp-content/uploads/2019/09/Buko-Pandan-Thumb-1024x683.jpg',
  },
  {
    id: 10,
    name: 'Turon',
    price: 50.0,
    description: 'Saging na binalot!', 
    image_url: 'https://panlasangpinoy.com/wp-content/uploads/2009/06/Turon.jpg',
  },
]

function formatToPhilippinePeso(amount) {
  return `₱${amount.toLocaleString('en-PH', { minimumFractionDigits: 2 })}`;
}

export default function Desserts({ navigation }) {
  const [cartItems, setCartItems] = useState([]);

  useEffect(() => {
    loadCart();
  }, []);

  const loadCart = async () => {
    try {
      const json = await AsyncStorage.getItem(CART_KEY);
      if (json) setCartItems(JSON.parse(json)); 
    } catch (error) {
      console.error(error);
    }
  };

  const saveCart = async (items) => {
    try {
      await AsyncStorage.setItem(CART_KEY, JSON.stringify(items)); 
    } catch (error) {
      console.error(error);
    }
  };

  const addToCart = (itemId) => {
    const item = desserts.find((item) => item.id === itemId);
    let updatedCart = [...cartItems];
    let existing = updatedCart.find((i) => i.id === itemId);
    if (existing) {
      existing.quantity++;
    } else {
      updatedCart.push({ id: itemId, quantity: 1 });
    }
    setCartItems(updatedCart);
    saveCart(updatedCart);
    Alert.alert('Added!', `${item.name} added to your order.`);
  };

  const renderFood = ({ item }) => (
    <View style={styles.card}>
      <Image source={{ uri: item.image_url }} style={styles.image} />
      <View style={styles.cardContent}>
        <Text style={styles.cardName}>{item.name}</Text>
        <Text style={styles.cardDesc}>{item.description}</Text>
        <Text style={styles.cardPrice}>{formatToPhilippinePeso(item.price)}</Text>
      </View>
      <TouchableOpacity style={styles.addBtn} onPress={() => addToCart(item.id)}>
        <Ionicons name="add-circle" size={30} color="#fff" />
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>
        Desserts
      </Text>
      <FlatList
        data={desserts}
        renderItem={renderFood}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.cardList}
      />
      <TouchableOpacity
        style={styles.viewCartBtn}
        onPress={() => navigation.navigate('Cart')}>
        <Text style={styles.viewCartBtnText}>
          View Cart
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({  
 container: {
    flex: 1,
    backgroundColor: '#35ac2b',
    padding: 20,
  },
  title: {
    color: 'black',
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 30,
    textTransform: 'uppercase',
    textAlign: 'center',
  },
  cardList: { paddingBottom: 100 },
  card: {
    backgroundColor: '#fff2cc',
    borderRadius: 20,
    padding: 15,
    marginBottom: 15,
    elevation: 4,
    borderWidth: 1,
    borderColor: '#ffcc5b',
    flexDirection: 'row',
    alignItems: 'center',
  },
  image: { width: 80, height: 80, borderRadius: 10, marginRight: 15 },
  cardContent: { flex: 1 },
  cardName: { fontWeight: 'bold', fontSize: 18, color: '#ff7e5f' },
  cardDesc: { color: '#ff9f5b', marginBottom: 5 },
  cardPrice: { color: '#ff7e5f', fontWeight: 'bold', marginBottom: 10 },
  addBtn: {
    backgroundColor: '#ff7e5f',
    padding: 10,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  viewCartBtn: {
    backgroundColor: '#ff7e5f',
    padding: 15,
    borderRadius: 30,
    alignItems: 'center',
    width: '80%',
    alignSelf: 'center',
    marginBottom: 30,
  },
  viewCartBtnText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
});
