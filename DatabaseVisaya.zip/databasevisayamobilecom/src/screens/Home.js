import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function Home({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>
        Pinoy Food Delivery
      </Text>

      <TouchableOpacity
        style={styles.card}
        onPress={() => navigation.navigate('MainDishes')}>
        <Text style={styles.cardText}>
          🍛 Main Dishes
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.card}
        onPress={() => navigation.navigate('Desserts')}>
        <Text style={styles.cardText}>
          🍨 Desserts
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.card}
        onPress={() => navigation.navigate('Snacks')}>
        <Text style={styles.cardText}>
          🍥 Snacks
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.card}
        onPress={() => navigation.navigate('Cart')}>
        <Text style={styles.cardText}>
          🛒 View Cart
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({  
  container: {
    flex: 1,
    backgroundColor: 'limegreen',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    color: 'black',
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 30,
    textTransform: 'uppercase',
  },
  card: {
    backgroundColor: 'green',
    padding: 20,
    borderRadius: 20,
    marginBottom: 15,
    width: '80%',
    alignItems: 'center',
    elevation: 4,
  },
  cardText: { color: '#fff', fontWeight: 'bold', fontSize: 18 },
});
