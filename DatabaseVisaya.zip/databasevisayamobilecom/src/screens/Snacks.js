import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  Image,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';

const CART_KEY = 'cart';

const snacks = [
  {
    id: 11,
    name: 'Banana Cue',
    price: 35.0,
    description: 'Saging na ginawang matamis!', 
    image_url: 'https://panlasangpinoy.com/wp-content/uploads/2011/10/Bananacue.jpg',
  },
  {
    id: 12,
    name: 'Kamote Cue',
    price: 30.0,
    description: 'Kamote na ginawang minatamis!', 
    image_url: 'https://panlasangpinoy.com/wp-content/uploads/2009/08/Kamote-Cue.jpg',
  },
  {
    id: 13,
    name: 'Fish Balls',
    price: 20.0,
    description: 'Masarap na meryenda!', 
    image_url: 'https://panlasangpinoy.com/wp-content/uploads/2011/10/Fish-Balls.jpg',
  },
  {
    id: 14,
    name: 'Kwek-Kwek',
    price: 25.0,
    description: 'Itlog na binalot!', 
    image_url: 'https://panlasangpinoy.com/wp-content/uploads/2009/09/kwekkwek-1024x76811.jpg',
  },
]

function formatToPhilippinePeso(amount) {
  return `₱${amount.toLocaleString('en-PH', { minimumFractionDigits: 2 })}`;
}

export default function Snacks({ navigation }) {
  const [cartItems, setCartItems] = useState([]);

  useEffect(() => {
    loadCart();
  }, []);

  const loadCart = async () => {
    try {
      const json = await AsyncStorage.getItem(CART_KEY);
      if (json) setCartItems(JSON.parse(json)); 
    } catch (error) {
      console.error(error);
    }
  };

  const saveCart = async (items) => {
    try {
      await AsyncStorage.setItem(CART_KEY, JSON.stringify(items)); 
    } catch (error) {
      console.error(error);
    }
  };

  const addToCart = (itemId) => {
    const item = snacks.find((item) => item.id === itemId);
    let updatedCart = [...cartItems];
    let existing = updatedCart.find((i) => i.id === itemId);
    if (existing) {
      existing.quantity++;
    } else {
      updatedCart.push({ id: itemId, quantity: 1 });
    }
    setCartItems(updatedCart);
    saveCart(updatedCart);
    Alert.alert('Added!', `${item.name} added to your order.`);
  };

  const renderFood = ({ item }) => (
    <View style={styles.card}>
      <Image source={{ uri: item.image_url }} style={styles.image} />
      <View style={styles.cardContent}>
        <Text style={styles.cardName}>{item.name}</Text>
        <Text style={styles.cardDesc}>{item.description}</Text>
        <Text style={styles.cardPrice}>{formatToPhilippinePeso(item.price)}</Text>
      </View>
      <TouchableOpacity style={styles.addBtn} onPress={() => addToCart(item.id)}>
        <Ionicons name="add-circle" size={30} color="#fff" />
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>
        Snacks
      </Text>
      <FlatList
        data={snacks}
        renderItem={renderFood}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.cardList}
      />
      <TouchableOpacity
        style={styles.viewCartBtn}
        onPress={() => navigation.navigate('Cart')}>
        <Text style={styles.viewCartBtnText}>
          View Cart
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({  
   container: {
    flex: 1,
    backgroundColor: '#35ac2b',
    padding: 20,
  },
  title: {
    color: 'black',
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 30,
    textTransform: 'uppercase',
    textAlign: 'center',
  },
  cardList: { paddingBottom: 100 },
  card: {
    backgroundColor: '#fff2cc',
    borderRadius: 20,
    padding: 15,
    marginBottom: 15,
    elevation: 4,
    borderWidth: 1,
    borderColor: '#ffcc5b',
    flexDirection: 'row',
    alignItems: 'center',
  },
  image: { width: 80, height: 80, borderRadius: 10, marginRight: 15 },
  cardContent: { flex: 1 },
  cardName: { fontWeight: 'bold', fontSize: 18, color: '#ff7e5f' },
  cardDesc: { color: '#ff9f5b', marginBottom: 5 },
  cardPrice: { color: '#ff7e5f', fontWeight: 'bold', marginBottom: 10 },
  addBtn: {
    backgroundColor: '#ff7e5f',
    padding: 10,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  viewCartBtn: {
    backgroundColor: '#ff7e5f',
    padding: 15,
    borderRadius: 30,
    alignItems: 'center',
    width: '80%',
    alignSelf: 'center',
    marginBottom: 30,
  },
  viewCartBtnText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
});
