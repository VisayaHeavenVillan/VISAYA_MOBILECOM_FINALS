import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Home from './src/screens/Home';
import MainDishes from './src/screens/MainDishes';
import Desserts from './src/screens/Desserts';
import Snacks from './src/screens/Snacks';
import Cart from './src/screens/Cart';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={Home} options={{ headerShown: false }} />
        <Stack.Screen name="MainDishes" component={MainDishes} options={{ title: 'Main Dishes' }} />
        <Stack.Screen name="Desserts" component={Desserts} options={{ title: 'Desserts' }} />
        <Stack.Screen name="Snacks" component={Snacks} options={{ title: 'Snacks' }} />
        <Stack.Screen name="Cart" component={Cart} options={{ title: 'Your Cart' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

